import ProductComponent from "./ProductComponent";

import "./ProductListing.css";
const ProductListing = () => {
  return (
    <div className="product-container-parent">
      <ProductComponent />
    </div>
  );
};

export default ProductListing;
