

import payment from "./payment.webp";
import productPayment from "./productPayment.webp";
import homeBanner from "./homeBanner.jpg";
import bannerOne from "./bannerOne.webp";
import bannerTwo from "./bannerTwo.webp";
import bannerThree from "./bannerThree.webp";
import bannerFour from "./bannerFour.png";

export {
  
  payment,
  productPayment,
  homeBanner,
  bannerOne,
  bannerTwo,
  bannerThree,
  bannerFour,
};
