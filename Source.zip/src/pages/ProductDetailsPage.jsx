import React from "react";
import ProductDetails from "../components/Product/ProductDetails";

export default function ProductDetailsPage() {
  return (
    <>
      <ProductDetails />
    </>
  );
}
