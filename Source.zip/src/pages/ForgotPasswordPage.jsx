import React from "react";
import ForgotPasswordForm from "../components/User/ForgotPasswordForm";

export default function ForgotPasswordPage() {
  return (
    <>
      <ForgotPasswordForm />
    </>
  );
}
