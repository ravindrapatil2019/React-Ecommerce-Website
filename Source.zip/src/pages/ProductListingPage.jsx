import React from "react";
import ProductListing from "../components/Product/ProductListing";
export default function ProductListingPage() {
  return (
    <>
      <ProductListing />
    </>
  );
}
