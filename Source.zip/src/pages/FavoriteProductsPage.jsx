import React from "react";
import FavoriteProducts from "../components/Favorite/FavoriteProducts";

export default function FavoriteProductsPage() {
  return (
    <>
      <FavoriteProducts />
    </>
  );
}
