import React from "react";

function CheckoutPage() {
  return <div>CheckoutPage</div>;
}

export default CheckoutPage;
