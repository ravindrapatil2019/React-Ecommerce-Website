import React from "react";
import Orders from "../components/Order/Orders";

function OrdersPage() {
  return (
    <>
      <Orders />
    </>
  );
}

export default OrdersPage;
