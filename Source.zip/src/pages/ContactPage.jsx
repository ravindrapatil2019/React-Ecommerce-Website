import React from "react";
import Contact from "../components/Common/Contact";
export default function ContactPage() {
  return (
    <>
      <Contact />
    </>
  );
}
