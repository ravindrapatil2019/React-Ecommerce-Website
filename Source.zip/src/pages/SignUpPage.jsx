import React from "react";
import SignUpForm from "../components/User/SignUpForm";

export default function SignUpPage() {
  return (
    <>
      <SignUpForm />
    </>
  );
}
