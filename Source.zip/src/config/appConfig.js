const apiConfig = {
    noOfItemPerPage: 8,
};

export default apiConfig;