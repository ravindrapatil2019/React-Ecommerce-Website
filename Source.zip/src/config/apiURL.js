const appConfig = {
    BASE_URL: 'https://fakestoreapi.com/products',
};

export default appConfig;
